package Projeto_P2;

import java.util.ArrayList;

public class RepositorioLocacao {
	private ArrayList<Locacao> listaLocacoes = new ArrayList<>();
}
