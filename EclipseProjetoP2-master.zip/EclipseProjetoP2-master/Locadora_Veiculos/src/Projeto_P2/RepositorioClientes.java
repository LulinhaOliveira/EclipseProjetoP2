
package Projeto_P2;

import java.util.ArrayList;

public class RepositorioClientes {
	private ArrayList<Cliente> listaClientes = new ArrayList<>();
}
