package Projeto_P2;

public class Funcionario extends Pessoa {

	private String setor;

	public void lista_de_veiculos() {

	}

	public void cadastrar_cliente() {

	}

	public void cancelar_cadastro() {

	}

	public void cadastrar_veiculo() {

	}

	public void remover_veiculo() {

	}


	public String getSetor() {
		return setor;
	}

	public void setSetor(String setor) {
		this.setor = setor;
	}

}
