package Projeto_P2;

import java.util.ArrayList;

public class RepositorioVeiculos {
	private ArrayList<Veiculos> listaVeiculos = new ArrayList<>();
}
