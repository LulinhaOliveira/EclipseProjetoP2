package Projeto_P2;

import java.util.ArrayList;

public class RepositorioFuncionarios {
	private ArrayList<Funcionario> listaFuncionario = new ArrayList<>();
}
