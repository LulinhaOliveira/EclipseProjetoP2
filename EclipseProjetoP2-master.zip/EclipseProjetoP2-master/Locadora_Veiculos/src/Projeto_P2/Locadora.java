package Projeto_P2;

public class Locadora {

	public static void main(String[] args) {

	}

}
